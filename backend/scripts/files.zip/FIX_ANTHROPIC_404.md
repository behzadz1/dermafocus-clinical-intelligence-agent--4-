# Fix: Anthropic API 404 Error (Model Not Found)

Your RAG system works perfectly! The only issue is Claude model access.

---

## 🎯 Quick Fix (2 Minutes)

### Step 1: Test Your API Key & Find Available Models

```bash
cd backend
chmod +x scripts/test_anthropic_api.py
python3 scripts/test_anthropic_api.py
```

**This script will:**
- ✓ Test your Anthropic API key
- ✓ Find which Claude models you have access to
- ✓ Automatically update your .env with a working model
- ✓ Tell you exactly what to do

---

## 🔍 What's Happening

**Error:** `404 - model: claude-3-5-sonnet-20241022`

**Cause:** Your API key doesn't have access to this specific model version.

**Why?**
1. Model name might be outdated
2. Your API tier doesn't include this model
3. API key is for Console (not API)
4. Account needs verification/billing

---

## ⚡ Manual Fix (If Script Doesn't Work)

### Option 1: Try Claude 3 Haiku (Most Likely to Work)

```bash
cd backend

# Edit .env
nano .env

# Change this line:
CLAUDE_MODEL=claude-3-haiku-20240307

# Save and restart
pkill -f uvicorn
./quickstart.sh
```

**Claude 3 Haiku:**
- ✓ Available to all tiers
- ✓ Fast and cheap
- ✓ Perfect for this use case

### Option 2: Try Claude 3 Sonnet

```bash
# In .env
CLAUDE_MODEL=claude-3-sonnet-20240229
```

### Option 3: Try Claude 3 Opus (Best Quality, if you have access)

```bash
# In .env
CLAUDE_MODEL=claude-3-opus-20240229
```

---

## 🔧 Verify Your API Key

### Check Key Type

Go to: https://console.anthropic.com/settings/keys

**Make sure:**
- ✓ Key is for "API" (not "Console")
- ✓ Key is active (not deleted)
- ✓ Account has billing set up (even if free tier)

### Get a New Key

If your key doesn't work:

1. Go to: https://console.anthropic.com/settings/keys
2. Create new API key
3. Copy it
4. Update `.env`:
   ```bash
   ANTHROPIC_API_KEY=sk-ant-your-new-key-here
   ```

---

## 📊 Model Comparison

| Model | Speed | Quality | Cost | Access |
|-------|-------|---------|------|--------|
| Claude 3 Haiku | ⚡⚡⚡ | ⭐⭐⭐ | $ | All tiers |
| Claude 3 Sonnet | ⚡⚡ | ⭐⭐⭐⭐ | $$ | Most tiers |
| Claude 3.5 Sonnet | ⚡⚡ | ⭐⭐⭐⭐⭐ | $$$ | Paid tiers |
| Claude 3 Opus | ⚡ | ⭐⭐⭐⭐⭐ | $$$$ | Paid tiers |

**For your use case (RAG assistant), Haiku or Sonnet is perfect!**

---

## ✅ After Fixing

### Test it works:

```bash
# Quick test
curl -X POST "http://localhost:8000/api/chat" \
  -H "Content-Type: application/json" \
  -d '{"question": "What is Plinest?"}' | jq
```

**Expected:** No 404 error, get actual answer!

### Run full tests:

```bash
python3 scripts/test_phase4.py
```

**Expected:** All 4 tests pass ✓

---

## 🐛 Still Getting 404?

### Debug Steps:

**1. Verify API key is correct:**
```bash
grep ANTHROPIC_API_KEY .env
```

Should start with `sk-ant-`

**2. Test API key directly:**
```bash
curl https://api.anthropic.com/v1/messages \
  --header "x-api-key: YOUR_API_KEY" \
  --header "anthropic-version: 2023-06-01" \
  --header "content-type: application/json" \
  --data '{
    "model": "claude-3-haiku-20240307",
    "max_tokens": 10,
    "messages": [{"role": "user", "content": "Hi"}]
  }'
```

**If this returns 404:**
- ❌ API key doesn't have model access
- → Get new API key from Console
- → Make sure account has billing set up

**If this works:**
- ✓ API key is fine
- → Issue is in backend config
- → Check .env file loaded correctly
- → Restart backend

---

## 💡 Common Solutions

### Solution 1: Use Haiku (Works 99% of time)

```bash
# .env file
CLAUDE_MODEL=claude-3-haiku-20240307
```

### Solution 2: Check Billing

Go to: https://console.anthropic.com/settings/billing

- Add payment method
- Verify account active
- Check usage limits

### Solution 3: New API Key

Sometimes keys get corrupted or limited:

1. Delete old key in Console
2. Create fresh API key
3. Update .env
4. Restart backend

---

## 🎯 Recommended Configuration

**For your RAG assistant, use:**

```bash
# .env optimized for RAG
CLAUDE_MODEL=claude-3-haiku-20240307
CLAUDE_MAX_TOKENS=2000
CLAUDE_TEMPERATURE=0.2
VECTOR_SEARCH_TOP_K=5
```

**Why Haiku?**
- ✓ Fast responses (1-2s)
- ✓ Cheap (~$0.25 per 1M tokens)
- ✓ Available to all tiers
- ✓ Perfect quality for RAG with good context

**Cost comparison for 1000 queries:**
- Haiku: ~$2-3
- Sonnet: ~$10-15
- Opus: ~$50-75

---

## ⚡ Quick Command Reference

```bash
# Test API key and find models
python3 scripts/test_anthropic_api.py

# Update to Haiku (most compatible)
echo "CLAUDE_MODEL=claude-3-haiku-20240307" >> .env

# Restart backend
pkill -f uvicorn && ./quickstart.sh

# Test it works
curl -X POST "http://localhost:8000/api/chat" \
  -d '{"question": "test"}' | jq '.answer'

# Run full tests
python3 scripts/test_phase4.py
```

---

## 🎉 Success Indicators

**After fixing, you should see:**

```bash
curl -X POST "http://localhost:8000/api/chat" \
  -d '{"question": "What is Plinest?"}'
```

**Response:**
```json
{
  "answer": "Plinest is a dermal filler containing...",
  "sources": [...],
  "confidence": 0.87,
  "follow_ups": [...]
}
```

**NOT:**
```json
{
  "detail": "Error code: 404 - model: claude-..."
}
```

---

## 📞 If Still Stuck

**Run this and share output:**

```bash
cd backend

# Check config
echo "=== API Key ==="
grep ANTHROPIC_API_KEY .env | cut -c1-30

echo "=== Model ==="
grep CLAUDE_MODEL .env

echo "=== Test API ==="
python3 scripts/test_anthropic_api.py
```

Share the output and I'll help!

---

**Start with the test script - it will find a working model for you:**

```bash
python3 scripts/test_anthropic_api.py
```

This should fix it in 2 minutes! 🚀
