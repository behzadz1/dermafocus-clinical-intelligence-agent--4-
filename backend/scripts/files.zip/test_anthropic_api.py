#!/usr/bin/env python3
"""
Test Anthropic API Access and Find Available Models
"""

import os
import sys

def test_anthropic_api():
    """Test Anthropic API key and find available models"""
    
    print("=" * 70)
    print("Anthropic API Access Test")
    print("=" * 70)
    print()
    
    # Check if API key is set
    from app.config import settings
    
    api_key = settings.anthropic_api_key
    
    if not api_key or api_key == "your-anthropic-api-key-here":
        print("❌ ANTHROPIC_API_KEY not configured!")
        print()
        print("To fix:")
        print("1. Go to: https://console.anthropic.com/settings/keys")
        print("2. Create an API key")
        print("3. Add to .env file:")
        print("   ANTHROPIC_API_KEY=sk-ant-...")
        return False
    
    print(f"✓ API key found: {api_key[:20]}...")
    print()
    
    # Try to import Anthropic
    try:
        from anthropic import Anthropic
    except ImportError:
        print("❌ Anthropic library not installed!")
        print("Run: pip install anthropic")
        return False
    
    print("✓ Anthropic library installed")
    print()
    
    # Initialize client
    try:
        client = Anthropic(api_key=api_key)
        print("✓ Client initialized")
        print()
    except Exception as e:
        print(f"❌ Failed to initialize client: {e}")
        return False
    
    # Test different models
    print("Testing available models...")
    print("-" * 70)
    
    models_to_test = [
        # Latest models (as of knowledge cutoff)
        ("claude-3-5-sonnet-20241022", "Claude 3.5 Sonnet (Latest)"),
        ("claude-3-5-sonnet-20240620", "Claude 3.5 Sonnet (June 2024)"),
        
        # Claude 3 family
        ("claude-3-opus-20240229", "Claude 3 Opus"),
        ("claude-3-sonnet-20240229", "Claude 3 Sonnet"),
        ("claude-3-haiku-20240307", "Claude 3 Haiku"),
        
        # Older models (fallback)
        ("claude-2.1", "Claude 2.1 (Legacy)"),
        ("claude-2.0", "Claude 2.0 (Legacy)"),
    ]
    
    working_models = []
    
    for model_id, model_name in models_to_test:
        try:
            print(f"\nTesting: {model_name}")
            print(f"Model ID: {model_id}")
            
            response = client.messages.create(
                model=model_id,
                max_tokens=10,
                messages=[{"role": "user", "content": "Hi"}]
            )
            
            print(f"  ✓ SUCCESS - This model works!")
            working_models.append((model_id, model_name))
            
        except Exception as e:
            error_str = str(e)
            if "404" in error_str or "not_found" in error_str:
                print(f"  ✗ NOT FOUND - No access to this model")
            elif "401" in error_str or "authentication" in error_str.lower():
                print(f"  ✗ AUTH ERROR - API key invalid")
                return False
            elif "429" in error_str or "rate_limit" in error_str.lower():
                print(f"  ⚠ RATE LIMITED - Try again in a moment")
            else:
                print(f"  ✗ ERROR - {error_str[:100]}")
    
    print()
    print("=" * 70)
    print("RESULTS")
    print("=" * 70)
    print()
    
    if working_models:
        print(f"✓ You have access to {len(working_models)} model(s):")
        print()
        
        for model_id, model_name in working_models:
            print(f"  • {model_name}")
            print(f"    ID: {model_id}")
            print()
        
        # Recommend the best model
        recommended = working_models[0]
        print("RECOMMENDED MODEL:")
        print(f"  {recommended[1]}")
        print(f"  ID: {recommended[0]}")
        print()
        
        print("To use this model, update your .env file:")
        print(f"  CLAUDE_MODEL={recommended[0]}")
        print()
        
        # Auto-update .env if possible
        try:
            env_path = ".env"
            if os.path.exists(env_path):
                print("Would you like to update .env automatically? (y/n): ", end="")
                response = input().strip().lower()
                
                if response == 'y':
                    # Read current .env
                    with open(env_path, 'r') as f:
                        lines = f.readlines()
                    
                    # Update or add CLAUDE_MODEL
                    updated = False
                    new_lines = []
                    
                    for line in lines:
                        if line.startswith('CLAUDE_MODEL='):
                            new_lines.append(f'CLAUDE_MODEL={recommended[0]}\n')
                            updated = True
                        else:
                            new_lines.append(line)
                    
                    if not updated:
                        new_lines.append(f'\nCLAUDE_MODEL={recommended[0]}\n')
                    
                    # Write back
                    with open(env_path, 'w') as f:
                        f.writelines(new_lines)
                    
                    print(f"✓ Updated .env with CLAUDE_MODEL={recommended[0]}")
                    print()
                    print("Restart backend for changes to take effect:")
                    print("  pkill -f uvicorn && ./quickstart.sh")
        except Exception as e:
            print(f"Could not auto-update .env: {e}")
        
        return True
    else:
        print("❌ No working models found!")
        print()
        print("Possible causes:")
        print("  1. API key is invalid")
        print("  2. API key doesn't have access to Claude models")
        print("  3. Account not set up properly")
        print()
        print("Solutions:")
        print("  1. Check your API key at: https://console.anthropic.com/settings/keys")
        print("  2. Verify your account has API access (not just Console access)")
        print("  3. Check account status/billing: https://console.anthropic.com/settings/billing")
        print("  4. Try creating a new API key")
        print()
        
        return False


if __name__ == "__main__":
    # Add parent directory to path
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    
    success = test_anthropic_api()
    sys.exit(0 if success else 1)
